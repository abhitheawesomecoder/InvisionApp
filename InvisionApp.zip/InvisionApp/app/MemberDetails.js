import React, { Component } from 'react';
import {
View,
Text,
StyleSheet,
StatusBar,
Dimensions,
Image,
ScrollView,
TouchableHighlight
} from 'react-native';
const uri = 'https://pickaface.net/gallery/avatar/unr_stefanstrahinja_161227_0143_qxepfvq.png';
const { width, height } = Dimensions.get('window');
export default class MemberDetails extends Component {
  back(){
      this.props.navigator.pop();
    }


  render() {
    return (
        <View style={styles.container}>
        <StatusBar barStyle="light-content" />
                <View style={styles.toolbar}>
                  <TouchableHighlight onPress={() => this.back() } underlayColor="transparent">
                    <Text style={styles.toolbarButton}><Text style={{fontWeight: "bold"}}>&lt;</Text> Back</Text>
                  </TouchableHighlight>
                    <Text style={styles.toolbarTitle}>Member Details</Text>
                    <Text style={styles.toolbarButton}></Text>
                </View>
        <ScrollView>
        <View style={styles.profile}>
          <Image
            style={styles.avatar}
            source={{ url: "https://graph.facebook.com/"+this.props.title.id+"/picture?fields=redirect,url&type=large" }}/>
            <Text style={styles.name}>{this.props.title.name}, 29</Text>
            <Text style={styles.place}>New York, United States of America</Text>
            <Text style={styles.points}>4,976 Points Needed for Chemo Treatment</Text>
        </View>

        <View style={styles.about}>
        <Text style={styles.title}>
        About {this.props.title.name}
        </Text>
        <Text style={styles.details}>
        {this.props.title.about}
        </Text>
        <Text style={[styles.details,{marginTop: 5}]}>
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
        </Text>

        </View>
        </ScrollView>
        </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  toolbar:{
        backgroundColor:'#2a4e6c',
        paddingTop:30,
        paddingBottom:10,
        flexDirection:'row'
    },
    toolbarButton:{
        width: 50,
        color:'#fff',
        textAlign:'center'
    },
    toolbarTitle:{
        color:'#fff',
        textAlign:'center',
        fontWeight:'bold',
        flex:1
    },
    profile:{
      marginTop: 10,
    //  alignSelf: "center",
      alignItems: "center",
      height: height/3.4,
    },
    about:{

    },
    avatar: {
    marginBottom:10,
    width: 70,
    height: 70,
    borderRadius: 35
  },
  name:{
    color: "grey"
  },
  place:{
    color: "grey",
    fontSize: 9
  },
  points:{
    color: "grey"

  },
  title: {
    marginLeft:10,
    marginRight:10,
    fontWeight: "bold",
    color: "#4c4c4c"
  },
  details: {
    color: "grey",
    marginLeft:10,
    marginRight:10,
    marginTop:3,
    fontSize: 10
  }
})
