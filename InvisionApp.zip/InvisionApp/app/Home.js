import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Image,
  Touch,
  TouchableHighlight
} from 'react-native';
import MemberDetails from'./MemberDetails';
const FBSDK = require('react-native-fbsdk');
const {
  LoginManager,
  AccessToken
} = FBSDK;

const { width, height } = Dimensions.get('window');
//import SplashScreen from 'react-native-splash-screen'
import LinearGradient from 'react-native-linear-gradient';
var Carousel = require('react-native-carousel');
export default class InvisionApp extends Component {
  constructor(){
  super();

    this.state = {
      homejsx: (<View></View>),
    }
  }
  initUser(token) {
  fetch('https://graph.facebook.com/v2.8/me?fields=email,name,about&access_token=' + token)
  .then((response) => response.json())
  .then((json) => {
    // Some user object has been set up somewhere, build that user here
  /*  user.name = json.name
    user.id = json.id
    user.user_friends = json.friends
    user.email = json.email
    user.username = json.name
    user.loading = false
    user.loggedIn = true
    user.avatar = setAvatar(json.id)*/
    //console.log(json);
    //console.log(json.picture.data.url);
    this._nav(json);
  })
  .catch(function(err) {
	  console.log(err);
});
}
_nav(userDetails){
  this.props.navigator.push({
     title: userDetails,
     component: MemberDetails
   })
}
  componentDidMount() {
         // do anything while splash screen keeps, use await to wait for an async task.
         setTimeout(() => {
         this.setState({ homejsx:

<View style={styles.container}>
<View style={{flex : .75}}>
  <Image style={{width: width, resizeMode:"contain",   backgroundColor: "pink" }} source={ require('./images/slider1.png') } />
</View>
<View style={{flex : .25}}>
<LinearGradient colors={['#4c669f', '#3b5998', '#192f6a']} style={styles.linearGradient}>
  <Text style={styles.buttonText}>
    Sign in with Facebook
  </Text>
</LinearGradient>
</View>


</View>




         })
       },1000);
      //  SplashScreen.hide();
  }
  _fblogin(){
        LoginManager.logInWithReadPermissions(['public_profile'])
        .then((result) => this._handleCallBack(result),
          function(error) {
            alert('Login fail with error: ' + error);
          }
        )
  }
  _handleCallBack(result){
    if (result.isCancelled) {
      alert('Login cancelled');
    } else {
  //    alert('Login success with permissions: '
  //      +result.grantedPermissions.toString());
  AccessToken.getCurrentAccessToken().then(
          (data) => {
            //alert(data.accessToken.toString())
            this.initUser(data.accessToken)

          }
        )

    }


  }
  render() {
    return (
      <View style={styles.container}>

         <View style={{flex : .90}}>

         <Carousel width={width} indicatorOffset={10} animate={false} hideIndicators={true}>
          <View style={styles.slidescontainer}>
              <Image style={{width: width,flex: 1}} source={ require('./images/slider1.png') } />
          </View>
          <View style={styles.slidescontainer}>
             <Image style={{width: width,flex: 1 }} source={ require('./images/slider1.png') } />
          </View>
          <View style={styles.slidescontainer}>
             <Image style={{width: width,flex: 1 }} source={ require('./images/slider1.png') } />
          </View>
         </Carousel>

         </View>

        <View style={{flex : .10, padding: 10}}>
        <Text style={styles.message}>We&#39;ll never post without you permission</Text>
         <View style={{ alignSelf: "center"}}>
         <TouchableHighlight onPress={() => this._fblogin() } underlayColor="transparent">
            <LinearGradient colors={['#4c669f', '#3b5998', '#192f6a']} style={styles.linearGradient}>
              <Text style={styles.buttonText}>
                Sign in with Facebook
              </Text>
            </LinearGradient>
          </TouchableHighlight>
          </View>
        </View>
          </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  slidescontainer: {
    width: width,
    flex: 1,


  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  linearGradient: {
    paddingLeft: 40,
    paddingRight: 40,
    borderRadius: 25
  },
  buttonText: {
    fontSize: 18,
    fontFamily: 'Gill Sans',
    textAlign: 'center',
    margin: 10,
    color: '#ffffff',
    backgroundColor: 'transparent',
  },
  message:{
    alignSelf: "center",
    fontSize: 7,
    color: "grey",
    marginBottom: 7
  }
});

/*
<Carousel width={width} indicatorOffset={10} animate={false}>
 <View style={styles.slidescontainer}>
     <Image style={{width: width, resizeMode: "contain" }} source={ require('./images/slider1.png') } />
 </View>
 <View style={styles.slidescontainer}>
    <Image style={{width: width, resizeMode: "contain" }} source={ require('./images/slider1.png') } />
 </View>
 <View style={styles.slidescontainer}>
    <Image style={{width: width, resizeMode: "contain" }} source={ require('./images/slider1.png') } />
 </View>
</Carousel>*/
