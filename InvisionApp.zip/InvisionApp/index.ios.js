import React, { Component } from 'react';
import {
  AppRegistry,
  Navigator
} from 'react-native';

//import MemberDetails from'./app/MemberDetails';
import Home from'./app/Home';

import CustomTransitions from'./app/components/CustomTransitions';

export default class InvisionApp extends Component {

  render() {
    return (
      <Navigator ref='navigator' configureScene={(route, routeStack) => CustomTransitions.NONE}
      initialRoute={{title: 'Common Questions', component: Home}}
      renderScene={(route, navigator) => {
          if(route.component){
            return React.createElement(route.component, { title: route.title ,navigator });
          }
        }}
      />
    );
  }
}


AppRegistry.registerComponent('InvisionApp', () => InvisionApp);
